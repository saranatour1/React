import React, { Component } from 'react';

class ToDo extends Component{
  render() {        
    return (            
      <>
            <h3>Things I need to Do</h3> 
            <ul>
              <li> Learn React</li>
              <li> Climb mount everist</li>
              <li>Run a marathon</li>
              <li> Feed the dogs </li>
            </ul>
      </>
      
    );    
}


}
export default ToDo;