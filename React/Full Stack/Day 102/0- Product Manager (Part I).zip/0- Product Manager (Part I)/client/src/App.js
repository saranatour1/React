import logo from './logo.svg';
import './App.css';
import FormInput from './components/FormInput';

function App() {
  return (
    <div className="App">
      <FormInput />
    </div>
  );
}

export default App;
